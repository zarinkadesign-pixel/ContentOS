"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_v3/export/excel_exporter.py"""

from __future__ import annotations

import io
from datetime import datetime
from typing import List, Optional

from openpyxl import Workbook
from openpyxl.styles import (
    Alignment, Border, Font, GradientFill, PatternFill, Side,
)
from openpyxl.utils import get_column_letter

from core.models import Listing, ListingStatus


# ── Palette ───────────────────────────────────────────────────────────────────

_HEADER_FILL   = PatternFill("solid", fgColor="1A3A5C")
_PENDING_FILL  = PatternFill("solid", fgColor="FFF3CD")
_POSTED_FILL   = PatternFill("solid", fgColor="D4EDDA")
_RENTED_FILL   = PatternFill("solid", fgColor="D6D8DB")
_REJECTED_FILL = PatternFill("solid", fgColor="F8D7DA")

_THIN = Side(style="thin", color="CCCCCC")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

_HEADER_FONT  = Font(bold=True, color="FFFFFF", size=10, name="Arial")
_BODY_FONT    = Font(size=10, name="Arial")
_TITLE_FONT   = Font(bold=True, size=14, name="Arial", color="1A3A5C")
_LINK_FONT    = Font(size=10, name="Arial", color="0563C1", underline="single")
_MONEY_FORMAT = '#,##0 "₸"'
_DATE_FORMAT  = 'DD.MM.YYYY HH:MM'


# ── Column definitions ────────────────────────────────────────────────────────

COLUMNS = [
    ("ID",            8,   "external_id"),
    ("Статус",        12,  "status_label"),
    ("Район",         14,  "district"),
    ("Адрес",         28,  "address"),
    ("Комнаты",       10,  "rooms_label"),
    ("Площадь м²",   11,  "area"),
    ("Этаж",          8,   "floor_str"),
    ("Цена ₸/мес",   15,  "price"),
    ("Депозит",       12,  "deposit"),
    ("Договор",       14,  "contract_months"),
    ("Удобства",      22,  "amenities"),
    ("Описание",      35,  "description"),
    ("Фото шт.",       9,  "photo_count"),
    ("Телефон",       16,  "landlord_phone"),
    ("TG владельца",  16,  "landlord_username"),
    ("Дата добавления", 18, "created_at"),
    ("Одобрено",      18,  "approved_at"),
    ("Опубликовано",  18,  "posted_count"),
    ("Сдано",         18,  "rented_at"),
]


def _row_fill(status: ListingStatus) -> Optional[PatternFill]:
    return {
        ListingStatus.PENDING:  _PENDING_FILL,
        ListingStatus.POSTED:   _POSTED_FILL,
        ListingStatus.RENTED:   _RENTED_FILL,
        ListingStatus.REJECTED: _REJECTED_FILL,
    }.get(status)


def _listing_to_values(lst: Listing) -> list:
    return [
        lst.external_id,
        {
            ListingStatus.PENDING:  "На модерации",
            ListingStatus.APPROVED: "Одобрено",
            ListingStatus.POSTED:   "Опубликовано",
            ListingStatus.RENTED:   "Сдано",
            ListingStatus.REJECTED: "Отклонено",
            ListingStatus.PAUSED:   "Приостановлено",
        }.get(lst.status, lst.status.value),
        lst.district,
        lst.address,
        "Студия" if lst.rooms == 0 else (f"{lst.rooms}-комн." if lst.rooms else "—"),
        lst.area,
        f"{lst.floor}/{lst.total_floors}" if lst.floor and lst.total_floors else (str(lst.floor) if lst.floor else "—"),
        lst.price or 0,
        lst.deposit,
        lst.contract_months,
        lst.amenities,
        lst.description[:200] if lst.description else "",
        len(lst.photos),
        lst.landlord_phone,
        lst.landlord_username,
        lst.created_at,
        lst.approved_at,
        lst.posted_count,
        lst.rented_at,
    ]


# ── Main export function ──────────────────────────────────────────────────────

def export_listings_to_xlsx(
    listings: List[Listing],
    filter_status: Optional[ListingStatus] = None,
    title: str = "Объявления аренды — Астана",
) -> bytes:
    """
    Экспортирует список объявлений в .xlsx.
    Возвращает bytes — готово для отправки в Telegram send_document.
    """
    if filter_status:
        listings = [l for l in listings if l.status == filter_status]

    wb = Workbook()
    ws = wb.active
    ws.title = "Объявления"

    # ── Заголовок документа ───────────────────────────────────────────────────
    ws.merge_cells("A1:S1")
    ws["A1"] = title
    ws["A1"].font = _TITLE_FONT
    ws["A1"].alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 28

    ws.merge_cells("A2:S2")
    ws["A2"] = f"Экспорт: {datetime.now().strftime('%d.%m.%Y %H:%M')} | Записей: {len(listings)}"
    ws["A2"].font = Font(size=9, name="Arial", color="888888")
    ws.row_dimensions[2].height = 16

    # ── Пустая строка ─────────────────────────────────────────────────────────
    ws.row_dimensions[3].height = 8

    # ── Заголовки таблицы (строка 4) ──────────────────────────────────────────
    for col_idx, (col_name, col_width, _) in enumerate(COLUMNS, 1):
        cell = ws.cell(row=4, column=col_idx, value=col_name)
        cell.font       = _HEADER_FONT
        cell.fill       = _HEADER_FILL
        cell.border     = _BORDER
        cell.alignment  = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.column_dimensions[get_column_letter(col_idx)].width = col_width

    ws.row_dimensions[4].height = 24

    # ── Данные ────────────────────────────────────────────────────────────────
    for row_offset, lst in enumerate(listings, 5):
        values = _listing_to_values(lst)
        fill   = _row_fill(lst.status)
        is_even = (row_offset % 2 == 0)

        for col_idx, val in enumerate(values, 1):
            cell = ws.cell(row=row_offset, column=col_idx, value=val)
            cell.font      = _BODY_FONT
            cell.border    = _BORDER
            cell.alignment = Alignment(vertical="center", wrap_text=(col_idx in {4, 11, 12}))

            # Фон строки по статусу (или чередование)
            if fill:
                cell.fill = fill
            elif is_even:
                cell.fill = PatternFill("solid", fgColor="F8F9FA")

            # Форматирование цены
            if col_idx == 8 and isinstance(val, (int, float)):
                cell.number_format = _MONEY_FORMAT

            # Форматирование дат
            if col_idx in {16, 17, 19} and isinstance(val, datetime):
                cell.number_format = _DATE_FORMAT

        ws.row_dimensions[row_offset].height = 20

    # ── Фиксация заголовков ───────────────────────────────────────────────────
    ws.freeze_panes = "A5"

    # ── Лист "Статистика" ─────────────────────────────────────────────────────
    ws_stats = wb.create_sheet("Статистика")
    _write_stats_sheet(ws_stats, listings)

    # ── Лист "Легенда" ────────────────────────────────────────────────────────
    ws_legend = wb.create_sheet("Легенда")
    _write_legend_sheet(ws_legend)

    # ── Вернуть bytes ─────────────────────────────────────────────────────────
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.getvalue()


def _write_stats_sheet(ws, listings: List[Listing]) -> None:
    """Лист со сводной статистикой."""
    ws["A1"] = "Статистика по объявлениям"
    ws["A1"].font = Font(bold=True, size=13, name="Arial", color="1A3A5C")

    total     = len(listings)
    by_status = {}
    by_rooms  = {}
    prices    = [l.price for l in listings if l.price]

    for lst in listings:
        by_status[lst.status.value] = by_status.get(lst.status.value, 0) + 1
        key = "Студия" if lst.rooms == 0 else (f"{lst.rooms}-комн." if lst.rooms else "Не указано")
        by_rooms[key] = by_rooms.get(key, 0) + 1

    row = 3
    ws.cell(row=row, column=1, value="Всего объявлений").font = Font(bold=True, name="Arial")
    ws.cell(row=row, column=2, value=total)
    row += 1

    ws.cell(row=row, column=1, value="Средняя цена ₸/мес").font = Font(bold=True, name="Arial")
    ws.cell(row=row, column=2, value=f"=AVERAGE(Объявления!H5:H{4+total})")
    ws.cell(row=row, column=2).number_format = _MONEY_FORMAT
    row += 1

    ws.cell(row=row, column=1, value="Мин цена").font = Font(bold=True, name="Arial")
    ws.cell(row=row, column=2, value=f"=MIN(Объявления!H5:H{4+total})")
    ws.cell(row=row, column=2).number_format = _MONEY_FORMAT
    row += 1

    ws.cell(row=row, column=1, value="Макс цена").font = Font(bold=True, name="Arial")
    ws.cell(row=row, column=2, value=f"=MAX(Объявления!H5:H{4+total})")
    ws.cell(row=row, column=2).number_format = _MONEY_FORMAT
    row += 2

    ws.cell(row=row, column=1, value="По статусу:").font = Font(bold=True, name="Arial")
    row += 1
    for status, count in by_status.items():
        ws.cell(row=row, column=1, value=status)
        ws.cell(row=row, column=2, value=count)
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="По комнатам:").font = Font(bold=True, name="Arial")
    row += 1
    for rooms, count in sorted(by_rooms.items()):
        ws.cell(row=row, column=1, value=rooms)
        ws.cell(row=row, column=2, value=count)
        row += 1

    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 18


def _write_legend_sheet(ws) -> None:
    ws["A1"] = "Легенда цветов"
    ws["A1"].font = Font(bold=True, size=12, name="Arial")

    legend = [
        ("На модерации",   "FFF3CD", "Ждёт одобрения администратора"),
        ("Опубликовано",   "D4EDDA", "Активное объявление в канале"),
        ("Сдано",          "D6D8DB", "Квартира сдана, объявление неактивно"),
        ("Отклонено",      "F8D7DA", "Отклонено модератором"),
    ]
    for i, (label, color, desc) in enumerate(legend, 3):
        ws.cell(row=i, column=1, value=label).fill = PatternFill("solid", fgColor=color)
        ws.cell(row=i, column=2, value=desc)

    ws.column_dimensions["A"].width = 18
    ws.column_dimensions["B"].width = 40


# ── Telegram helper ───────────────────────────────────────────────────────────

async def send_xlsx_to_admin(bot, admin_id: int, listings: List[Listing]) -> None:
    """Отправляет Excel-файл администратору."""
    from aiogram.types import BufferedInputFile

    xlsx_bytes = export_listings_to_xlsx(listings)
    filename   = f"astana_rent_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"

    await bot.send_document(
        chat_id=admin_id,
        document=BufferedInputFile(xlsx_bytes, filename=filename),
        caption=(
            f"📊 <b>Экспорт объявлений</b>\n"
            f"Всего: {len(listings)} шт.\n"
            f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M')}"
        ),
        parse_mode="HTML",
    )
