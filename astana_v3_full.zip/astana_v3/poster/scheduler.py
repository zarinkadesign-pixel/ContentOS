"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_bot_v2/poster/scheduler.py"""

from __future__ import annotations

import asyncio
import random
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

from aiogram import Bot
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramBadRequest, TelegramNetworkError
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputMediaPhoto,
    Message,
    URLInputFile,
)
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from core.config import AppConfig
from core.models import Listing, ListingStatus
from sheets.repository import SheetRepo

# Timezone Астаны = UTC+5
ASTANA_TZ = timezone(timedelta(hours=5))


class RandomScheduler:
    """
    Планировщик публикаций с рандомизацией.

    Алгоритм:
    1. При каждом тике — собирает список approved + posted объявлений.
    2. Фильтрует те, у которых next_post_at ≤ now ИЛИ next_post_at is None.
    3. Перемешивает список (random.shuffle).
    4. Публикует первые N штук с паузой post_delay_seconds.
    5. Устанавливает next_post_at = now + random(interval_min, interval_max).
    6. Объявления со статусом RENTED — пропускаются навсегда.
    """

    def __init__(self, bot: Bot, repo: SheetRepo, cfg: AppConfig) -> None:
        self._bot    = bot
        self._repo   = repo
        self._cfg    = cfg
        self._sc     = cfg.scheduler
        self._tc     = cfg.telegram
        self._posts_today = 0
        self._today_date  = datetime.now(ASTANA_TZ).date()

    # ── Public ────────────────────────────────────────────────────────────────

    async def tick(self) -> None:
        """Вызывается каждые N минут планировщиком APScheduler."""
        now = datetime.now(ASTANA_TZ)

        # Сброс счётчика в новый день
        if now.date() != self._today_date:
            self._posts_today = 0
            self._today_date  = now.date()

        # Проверка активных часов
        if not (self._sc.active_hour_start <= now.hour < self._sc.active_hour_end):
            logger.debug(f"[scheduler] Нерабочее время: {now.hour}:00")
            return

        # Лимит на день
        if self._posts_today >= self._sc.max_posts_per_day:
            logger.debug(f"[scheduler] Лимит дня достигнут: {self._posts_today}")
            return

        # Собираем очередь
        queue = self._build_queue(now)
        if not queue:
            logger.debug("[scheduler] Нет объявлений для публикации")
            return

        logger.info(f"[scheduler] В очереди: {len(queue)} объявлений")

        for listing in queue:
            if self._posts_today >= self._sc.max_posts_per_day:
                break
            msg_id = await self._post_listing(listing)
            if msg_id is not None:
                next_post = self._calc_next_post(now)
                listing.status = ListingStatus.POSTED
                self._repo.mark_listing_posted(listing, msg_id, next_post)
                self._posts_today += 1
                logger.info(
                    f"[scheduler] Опубликовано: {listing.external_id} "
                    f"(next: {next_post.strftime('%H:%M')})"
                )
            await asyncio.sleep(self._sc.post_delay_seconds)

    # ── Queue ─────────────────────────────────────────────────────────────────

    def _build_queue(self, now: datetime) -> List[Listing]:
        """
        Формирует очередь: approved (новые) + posted (которым пришло время репоста).
        Shuffle обеспечивает равномерное распределение по всем объявлениям.
        """
        approved = self._repo.get_approved_listings()
        posted   = self._repo.get_posted_listings()

        ready: List[Listing] = []

        # Новые — публикуем сразу
        ready.extend(approved)

        # Репосты — только если время пришло
        for lst in posted:
            if lst.next_post_at is None:
                ready.append(lst)
                continue
            # Приводим к aware datetime для сравнения
            npa = lst.next_post_at
            if npa.tzinfo is None:
                npa = npa.replace(tzinfo=timezone.utc)
            if npa <= now:
                ready.append(lst)

        # Перемешиваем — исключаем предсказуемость
        random.shuffle(ready)
        return ready[:5]  # Максимум 5 за один тик

    def _calc_next_post(self, now: datetime) -> datetime:
        """Рандомный интервал до следующей публикации этого объявления."""
        minutes = random.randint(
            self._sc.repost_interval_hours * 60,
            self._sc.repost_interval_hours * 60 + 180,  # +3 часа разброс
        )
        return now + timedelta(minutes=minutes)

    # ── Post ─────────────────────────────────────────────────────────────────

    async def _post_listing(self, listing: Listing) -> Optional[int]:
        """Публикует объявление в канал. Возвращает message_id или None."""
        caption = self._build_caption(listing)
        keyboard = self._build_keyboard(listing)
        photos = listing.photos  # Это file_id из Telegram

        if not photos:
            return await self._post_text(listing, caption, keyboard)

        if len(photos) == 1:
            return await self._post_single_photo(photos[0], caption, keyboard)

        return await self._post_media_group(photos, caption, keyboard)

    @retry(
        retry=retry_if_exception_type(TelegramNetworkError),
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=15),
    )
    async def _post_single_photo(
        self, file_id: str, caption: str, keyboard: InlineKeyboardMarkup
    ) -> Optional[int]:
        try:
            msg: Message = await self._bot.send_photo(
                chat_id=self._tc.channel_id,
                photo=file_id,
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
            )
            return msg.message_id
        except TelegramBadRequest as e:
            logger.warning(f"[scheduler] Ошибка фото: {e}")
            return None

    @retry(
        retry=retry_if_exception_type(TelegramNetworkError),
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=15),
    )
    async def _post_media_group(
        self, file_ids: List[str], caption: str, keyboard: InlineKeyboardMarkup
    ) -> Optional[int]:
        media = [
            InputMediaPhoto(
                media=fid,
                caption=caption if i == 0 else None,
                parse_mode=ParseMode.HTML if i == 0 else None,
            )
            for i, fid in enumerate(file_ids[:10])
        ]
        try:
            msgs = await self._bot.send_media_group(
                chat_id=self._tc.channel_id,
                media=media,
            )
            first_id = msgs[0].message_id
            # Кнопки — отдельным сообщением-ответом
            await self._bot.send_message(
                chat_id=self._tc.channel_id,
                text="👇 Действия с объявлением:",
                reply_markup=keyboard,
                reply_to_message_id=first_id,
            )
            return first_id
        except TelegramBadRequest as e:
            logger.warning(f"[scheduler] Media group error: {e}")
            return None

    @retry(
        retry=retry_if_exception_type(TelegramNetworkError),
        stop=stop_after_attempt(3),
        wait=wait_exponential(min=2, max=15),
    )
    async def _post_text(
        self, listing: Listing, caption: str, keyboard: InlineKeyboardMarkup
    ) -> Optional[int]:
        try:
            msg: Message = await self._bot.send_message(
                chat_id=self._tc.channel_id,
                text=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=keyboard,
                disable_web_page_preview=True,
            )
            return msg.message_id
        except TelegramBadRequest as e:
            logger.error(f"[scheduler] Text post error: {e}")
            return None

    # ── Caption ───────────────────────────────────────────────────────────────

    def _build_caption(self, listing: Listing) -> str:
        rooms_label = "Студия" if listing.rooms == 0 else f"{listing.rooms}-комн."
        price_str   = f"{listing.price:,}".replace(",", " ") + " ₸/мес"

        lines = [f"🏙 <b>{rooms_label} квартира в аренду — Астана</b>"]
        lines.append(f"💰 <b>{price_str}</b>")

        location = []
        if listing.district:
            location.append(listing.district)
        if listing.address:
            location.append(listing.address)
        if location:
            lines.append(f"📍 {', '.join(location)}")

        params = []
        if listing.area:
            params.append(f"{listing.area:.0f} м²")
        if listing.floor and listing.total_floors:
            params.append(f"этаж {listing.floor}/{listing.total_floors}")
        elif listing.floor:
            params.append(f"{listing.floor} эт.")
        if params:
            lines.append(f"🏢 {' · '.join(params)}")

        if listing.deposit:
            lines.append(f"🔑 Депозит: {listing.deposit}")
        if listing.contract_months:
            lines.append(f"📄 Договор: {listing.contract_months}")

        if listing.amenities:
            lines.append(f"✨ {listing.amenities}")

        if listing.description:
            desc = listing.description.strip()
            if len(desc) > 200:
                desc = desc[:197] + "…"
            lines.append(f"\n{desc}")

        if listing.landlord_phone:
            lines.append(f"\n📞 {listing.landlord_phone}")

        # Лимит caption для media group = 1024 символа
        text = "\n".join(lines)
        if len(text) > 1000:
            text = text[:997] + "…"
        return text

    # ── Keyboard ──────────────────────────────────────────────────────────────

    def _build_keyboard(self, listing: Listing) -> InlineKeyboardMarkup:
        rows = []

        # Ряд 1: Написать владельцу
        row1 = []
        if listing.landlord_username:
            uname = listing.landlord_username.lstrip("@")
            row1.append(InlineKeyboardButton(
                text="✍️ Написать владельцу",
                url=f"https://t.me/{uname}",
            ))
        elif listing.landlord_phone:
            phone = listing.landlord_phone.replace("+", "").replace(" ", "")
            row1.append(InlineKeyboardButton(
                text="✍️ Написать владельцу",
                url=f"https://t.me/+{phone}",
            ))
        if row1:
            rows.append(row1)

        # Ряд 2: Записаться на просмотр + Риелтор
        realtor = self._tc.realtor_username.lstrip("@")
        rows.append([
            InlineKeyboardButton(
                text="📅 Записаться на просмотр",
                callback_data=f"lead:{listing.external_id}",
            ),
            InlineKeyboardButton(
                text="🤝 Риелтор",
                url=f"https://t.me/{realtor}",
            ),
        ])

        # Ряд 3: Найти похожие
        district_short = (listing.district or "")[:15]
        rows.append([InlineKeyboardButton(
            text="🔍 Найти похожие",
            callback_data=f"similar:{listing.rooms or 0}:{district_short}",
        )])

        return InlineKeyboardMarkup(inline_keyboard=rows)
