"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_v3/main.py"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict

from aiogram import BaseMiddleware, Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import TelegramObject, Update
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from aiohttp import web
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent))

from core.config import get_config
from sheets.repository import SheetRepo
from poster.scheduler import RandomScheduler
from bot.landlord_fsm   import router as landlord_router
from bot.admin_handlers  import router as admin_router
from bot.tenant_handlers import router as tenant_router
from export.excel_exporter import export_listings_to_xlsx, send_xlsx_to_admin

MINIAPP_URL = os.getenv("MINIAPP_URL", "https://your-app.up.railway.app")


# ── Service Account из base64 (Railway deploy) ────────────────────────────────

def _decode_service_account_if_needed() -> None:
    """
    Если задана переменная GOOGLE_SA_B64 — декодирует и сохраняет JSON.
    Используется на Railway (нельзя хранить файлы между деплоями).
    """
    b64 = os.getenv("GOOGLE_SA_B64", "")
    if not b64:
        return
    sa_path = Path("secrets/service_account.json")
    if sa_path.exists():
        return  # Уже есть — не перезаписываем
    sa_path.parent.mkdir(parents=True, exist_ok=True)
    decoded = base64.b64decode(b64).decode()
    json.loads(decoded)  # Валидация
    sa_path.write_text(decoded)
    logger.info("[main] service_account.json декодирован из GOOGLE_SA_B64")


# ── DI Middleware ─────────────────────────────────────────────────────────────

class DIMiddleware(BaseMiddleware):
    def __init__(self, **deps: Any) -> None:
        self._deps = deps

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        data.update(self._deps)
        return await handler(event, data)


# ── Mini App API server ───────────────────────────────────────────────────────

async def make_api_app(repo: SheetRepo) -> web.Application:
    """
    Лёгкий aiohttp сервер для Mini App.
    GET /api/listings → JSON список опубликованных объявлений
    GET /               → Mini App HTML
    """
    app = web.Application()
    miniapp_html = Path("miniapp/index.html").read_text(encoding="utf-8")

    async def handle_root(request: web.Request) -> web.Response:
        return web.Response(text=miniapp_html, content_type="text/html")

    async def handle_listings(request: web.Request) -> web.Response:
        listings = repo.get_posted_listings()
        data = []
        for lst in listings:
            data.append({
                "external_id":       lst.external_id,
                "rooms":             lst.rooms,
                "area":              lst.area,
                "floor":             lst.floor,
                "total_floors":      lst.total_floors,
                "price":             lst.price,
                "district":          lst.district,
                "address":           lst.address,
                "description":       lst.description[:300] if lst.description else "",
                "amenities":         lst.amenities,
                "photos":            lst.photos[:3],
                "landlord_phone":    lst.landlord_phone,
                "landlord_username": lst.landlord_username,
                "deposit":           lst.deposit,
                "contract_months":   lst.contract_months,
                "created_at":        lst.created_at.isoformat() if lst.created_at else "",
            })
        return web.json_response(data, headers={"Access-Control-Allow-Origin": "*"})

    app.router.add_get("/", handle_root)
    app.router.add_get("/api/listings", handle_listings)
    return app


# ── Автоматические задачи ─────────────────────────────────────────────────────

async def auto_check_violations(repo: SheetRepo, bot: Bot, cfg) -> None:
    """
    Автоматически проверяет нарушения риелторов:
    - Не принял лид за 2 ч → предупреждение
    - Не отметил результат за 2 ч после просмотра → нарушение
    """
    from datetime import datetime, timedelta
    from core.models import LeadStatus, ViolationType

    now = datetime.utcnow()
    leads = repo.get_all_leads_by_status(LeadStatus.ASSIGNED)

    for lead in leads:
        if not lead.assigned_at:
            continue
        hours_elapsed = (now - lead.assigned_at).total_seconds() / 3600

        if hours_elapsed > cfg.realtor.viewing_deadline_hours:
            realtor = repo.get_realtor(lead.assigned_realtor_tg_id)
            if realtor:
                realtor.violations += 1
                _apply_violation_rules(realtor, cfg)
                repo.update_realtor(realtor)

                try:
                    await bot.send_message(
                        realtor.tg_id,
                        f"⚠️ <b>Нарушение!</b> Лид {lead.external_id} не обработан "
                        f"в течение {cfg.realtor.viewing_deadline_hours} ч.\n"
                        f"Нарушений: {realtor.violations}. Статус: {realtor.status.value}",
                        parse_mode=ParseMode.HTML,
                    )
                except Exception as e:
                    logger.warning(f"[violation] Не удалось уведомить: {e}")

                logger.info(f"[violation] Нарушение риелтора {realtor.tg_id}: лид {lead.external_id}")


def _apply_violation_rules(realtor, cfg) -> None:
    from core.models import RealtorStatus
    from datetime import datetime, timedelta

    realtor.rating = max(0.0, realtor.rating - 10)

    if realtor.violations >= cfg.realtor.ban_on_violation:
        realtor.status = RealtorStatus.BANNED
    elif realtor.violations >= cfg.realtor.freeze_on_violation:
        realtor.status = RealtorStatus.FROZEN
        realtor.frozen_until = datetime.utcnow() + timedelta(days=cfg.realtor.freeze_days)


async def auto_unfreeze_realtors(repo: SheetRepo, bot: Bot) -> None:
    """Автоматически размораживает риелторов у которых истёк срок заморозки."""
    from datetime import datetime
    from core.models import RealtorStatus

    all_realtors = repo.get_all_realtors()
    now = datetime.utcnow()

    for realtor in all_realtors:
        if realtor.status != RealtorStatus.FROZEN:
            continue
        if realtor.frozen_until and realtor.frozen_until <= now:
            realtor.status = RealtorStatus.ACTIVE
            realtor.frozen_until = None
            repo.update_realtor(realtor)
            try:
                await bot.send_message(
                    realtor.tg_id,
                    "✅ <b>Заморозка снята!</b> Вы снова можете получать заявки.",
                    parse_mode=ParseMode.HTML,
                )
            except Exception: pass
            logger.info(f"[unfreeze] Риелтор {realtor.tg_id} разморожен")


async def auto_daily_report(bot: Bot, repo: SheetRepo, cfg) -> None:
    """Ежедневный отчёт администратору в 09:00."""
    from datetime import datetime

    all_listings = (
        repo.get_pending_listings()
        + repo.get_approved_listings()
        + repo.get_posted_listings()
    )

    # Отправляем Excel
    for admin_id in cfg.telegram.admin_ids:
        try:
            await send_xlsx_to_admin(bot, admin_id, all_listings)
            logger.info(f"[report] Ежедневный отчёт отправлен администратору {admin_id}")
        except Exception as e:
            logger.error(f"[report] Ошибка отправки отчёта: {e}")


# ── Entry Point ───────────────────────────────────────────────────────────────

async def main() -> None:
    # Логирование
    logger.remove()
    logger.add(sys.stderr, format="<green>{time:HH:mm:ss}</green> | <level>{level:<7}</level> | {message}", level="INFO")
    Path("logs").mkdir(exist_ok=True)
    logger.add("logs/bot_{time:YYYY-MM-DD}.log", rotation="00:00", retention="14 days", level="DEBUG")

    # Service account
    _decode_service_account_if_needed()

    cfg = get_config()

    # Sheets
    repo = SheetRepo(cfg.sheets)
    repo.connect()

    # Bot + Dispatcher
    bot     = Bot(token=cfg.telegram.bot_token, parse_mode=ParseMode.HTML)
    storage = MemoryStorage()
    dp      = Dispatcher(storage=storage)

    # DI
    middleware = DIMiddleware(
        repo=repo, cfg=cfg,
        admin_ids=cfg.telegram.admin_ids,
        bot=bot,
        miniapp_url=MINIAPP_URL,
    )
    dp.update.outer_middleware(middleware)

    # Роутеры
    dp.include_router(tenant_router)
    dp.include_router(landlord_router)
    dp.include_router(admin_router)

    # Scheduler
    sched = RandomScheduler(bot=bot, repo=repo, cfg=cfg)
    ap    = AsyncIOScheduler(timezone="Asia/Almaty")

    ap.add_job(sched.tick,               "interval", minutes=15,  id="post",     max_instances=1)
    ap.add_job(repo.refresh_caches,      "interval", hours=1,     id="cache")
    ap.add_job(auto_check_violations,    "interval", hours=1,     id="violations",
               args=[repo, bot, cfg], max_instances=1)
    ap.add_job(auto_unfreeze_realtors,   "interval", hours=6,     id="unfreeze",
               args=[repo, bot])
    ap.add_job(auto_daily_report,        "cron",     hour=9, minute=0, id="daily_report",
               args=[bot, repo, cfg])

    ap.start()

    # Mini App API сервер
    api_app  = await make_api_app(repo)
    runner   = web.AppRunner(api_app)
    await runner.setup()
    port     = int(os.getenv("PORT", 8080))
    site     = web.TCPSite(runner, "0.0.0.0", port)
    await site.start()

    logger.info(
        f"[main] 🚀 Запущен\n"
        f"  Mini App API : http://0.0.0.0:{port}/api/listings\n"
        f"  Channel      : {cfg.telegram.channel_id}\n"
        f"  Admins       : {cfg.telegram.admin_ids}"
    )

    await sched.tick()  # Первый тик немедленно

    try:
        await dp.start_polling(bot, allowed_updates=Update.all_event_names())
    finally:
        ap.shutdown()
        await runner.cleanup()
        await bot.session.close()
        logger.info("[main] Остановлен")


if __name__ == "__main__":
    asyncio.run(main())
