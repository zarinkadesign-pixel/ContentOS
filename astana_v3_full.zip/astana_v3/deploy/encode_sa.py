#!/usr/bin/env python3
"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_v3/deploy/encode_sa.py

ИСПОЛЬЗОВАНИЕ:
  python deploy/encode_sa.py secrets/service_account.json

Скрипт берёт JSON файла service account Google и кодирует его в base64.
Полученную строку вставь в Railway как переменную GOOGLE_SA_B64.
Бот декодирует её обратно при старте.
"""

import base64
import json
import sys
from pathlib import Path


def encode_service_account(path: str) -> str:
    data = Path(path).read_text(encoding="utf-8")
    # Валидируем что это JSON
    json.loads(data)
    encoded = base64.b64encode(data.encode()).decode()
    return encoded


def decode_and_save(b64_str: str, output_path: str = "secrets/service_account.json") -> None:
    """Декодирует переменную окружения GOOGLE_SA_B64 → файл."""
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    data = base64.b64decode(b64_str).decode()
    json.loads(data)  # Валидация
    Path(output_path).write_text(data, encoding="utf-8")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Использование: python deploy/encode_sa.py <путь к service_account.json>")
        sys.exit(1)

    encoded = encode_service_account(sys.argv[1])
    print("\n" + "="*60)
    print("Скопируй эту строку в Railway → Variables → GOOGLE_SA_B64:")
    print("="*60)
    print(encoded)
    print("="*60 + "\n")
    print("Длина строки:", len(encoded))
