"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_bot_v2/sheets/repository.py"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Dict, List, Optional, Set

import gspread
from google.oauth2.service_account import Credentials
from loguru import logger
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from core.config import SheetsConfig
from core.models import (
    Listing, ListingStatus, LISTING_COLUMNS,
    Realtor, RealtorStatus, REALTOR_COLUMNS,
    Lead, LeadStatus, LEAD_COLUMNS,
    Settlement, SETTLEMENT_COLUMNS,
)

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive.readonly",
]

_RETRY = dict(
    retry=retry_if_exception_type(gspread.exceptions.APIError),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=2, min=2, max=30),
)


class SheetRepo:
    """
    Единый репозиторий для всех 4 листов Google Sheets.
    Каждый метод — одна атомарная операция с retry.
    """

    def __init__(self, cfg: SheetsConfig) -> None:
        self._cfg = cfg
        self._gc: Optional[gspread.Client] = None
        self._ws: Dict[str, gspread.Worksheet] = {}
        # Кэши для быстрой дедупликации
        self._listing_keys: Set[str] = set()
        self._realtor_ids: Set[int] = set()

    # ── Connect ───────────────────────────────────────────────────────────────

    def connect(self) -> None:
        creds = Credentials.from_service_account_file(
            str(self._cfg.service_account_json), scopes=SCOPES
        )
        self._gc = gspread.authorize(creds)
        ss = self._gc.open_by_key(self._cfg.spreadsheet_id)

        sheet_defs = [
            (self._cfg.sheet_listings,    LISTING_COLUMNS),
            (self._cfg.sheet_realtors,    REALTOR_COLUMNS),
            (self._cfg.sheet_leads,       LEAD_COLUMNS),
            (self._cfg.sheet_settlements, SETTLEMENT_COLUMNS),
        ]

        for name, columns in sheet_defs:
            try:
                ws = ss.worksheet(name)
            except gspread.WorksheetNotFound:
                ws = ss.add_worksheet(title=name, rows=5000, cols=len(columns))
                ws.append_row(columns)
                logger.info(f"[repo] Создан лист: {name}")
            self._ws[name] = ws

        self._reload_caches()
        logger.info(
            f"[repo] Подключено. Объявлений: {len(self._listing_keys)}, "
            f"Риелторов: {len(self._realtor_ids)}"
        )

    def _reload_caches(self) -> None:
        ws = self._ws[self._cfg.sheet_listings]
        col = ws.col_values(1)[1:]
        self._listing_keys = set(col)

        ws_r = self._ws[self._cfg.sheet_realtors]
        col_r = ws_r.col_values(1)[1:]
        self._realtor_ids = {int(x) for x in col_r if x.strip().isdigit()}

    # ── Listings ──────────────────────────────────────────────────────────────

    @retry(**_RETRY)
    def add_listing(self, listing: Listing) -> Listing:
        """Добавляет объявление, генерирует external_id, возвращает с row_index."""
        listing.external_id = str(uuid.uuid4())[:8].upper()
        row = listing.to_sheet_row()
        self._ws[self._cfg.sheet_listings].append_row(row, value_input_option="USER_ENTERED")
        self._listing_keys.add(listing.external_id)
        logger.info(f"[repo] Объявление добавлено: {listing.external_id}")
        return listing

    @retry(**_RETRY)
    def get_pending_listings(self) -> List[Listing]:
        """Все объявления со статусом pending — для модерации."""
        return self._get_listings_by_status(ListingStatus.PENDING)

    @retry(**_RETRY)
    def get_approved_listings(self) -> List[Listing]:
        """Все approved-объявления — для планировщика."""
        return self._get_listings_by_status(ListingStatus.APPROVED)

    @retry(**_RETRY)
    def get_posted_listings(self) -> List[Listing]:
        """Все активно опубликованные — для повторных публикаций."""
        return self._get_listings_by_status(ListingStatus.POSTED)

    def _get_listings_by_status(self, status: ListingStatus) -> List[Listing]:
        all_rows = self._ws[self._cfg.sheet_listings].get_all_values()
        results = []
        for i, row in enumerate(all_rows[1:], start=2):
            if len(row) > 17 and row[17] == status.value:
                try:
                    results.append(Listing.from_sheet_row(row, row_index=i))
                except Exception as e:
                    logger.warning(f"[repo] Строка {i} пропущена: {e}")
        return results

    @retry(**_RETRY)
    def update_listing_status(
        self,
        listing: Listing,
        new_status: ListingStatus,
        **extra_fields,
    ) -> None:
        """Обновляет статус и дополнительные поля."""
        if listing.row_index is None:
            logger.error(f"[repo] row_index is None: {listing.external_id}")
            return

        listing.status = new_status
        listing.updated_at = datetime.utcnow()

        if new_status == ListingStatus.APPROVED:
            listing.approved_at = datetime.utcnow()
        elif new_status == ListingStatus.RENTED:
            listing.rented_at = datetime.utcnow()

        # Batch update всей строки
        ws = self._ws[self._cfg.sheet_listings]
        ws.update(
            f"A{listing.row_index}",
            [listing.to_sheet_row()],
            value_input_option="USER_ENTERED",
        )
        logger.info(f"[repo] Статус обновлён: {listing.external_id} → {new_status.value}")

    @retry(**_RETRY)
    def mark_listing_posted(
        self, listing: Listing, message_id: int, next_post_at: datetime
    ) -> None:
        listing.status = ListingStatus.POSTED
        listing.channel_message_id = message_id
        listing.posted_count += 1
        listing.next_post_at = next_post_at
        listing.updated_at = datetime.utcnow()
        ws = self._ws[self._cfg.sheet_listings]
        ws.update(
            f"A{listing.row_index}",
            [listing.to_sheet_row()],
            value_input_option="USER_ENTERED",
        )

    def get_listing_by_id(self, external_id: str) -> Optional[Listing]:
        all_rows = self._ws[self._cfg.sheet_listings].get_all_values()
        for i, row in enumerate(all_rows[1:], start=2):
            if row and row[0] == external_id:
                return Listing.from_sheet_row(row, row_index=i)
        return None

    # ── Realtors ──────────────────────────────────────────────────────────────

    @retry(**_RETRY)
    def add_realtor(self, realtor: Realtor) -> Realtor:
        if realtor.tg_id in self._realtor_ids:
            raise ValueError(f"Риелтор {realtor.tg_id} уже существует")
        self._ws[self._cfg.sheet_realtors].append_row(
            realtor.to_sheet_row(), value_input_option="USER_ENTERED"
        )
        self._realtor_ids.add(realtor.tg_id)
        logger.info(f"[repo] Риелтор добавлен: {realtor.tg_id}")
        return realtor

    def is_realtor(self, tg_id: int) -> bool:
        return tg_id in self._realtor_ids

    @retry(**_RETRY)
    def get_realtor(self, tg_id: int) -> Optional[Realtor]:
        col = self._ws[self._cfg.sheet_realtors].col_values(1)
        for i, val in enumerate(col[1:], start=2):
            if val.strip() == str(tg_id):
                row = self._ws[self._cfg.sheet_realtors].row_values(i)
                return Realtor.from_sheet_row(row, row_index=i)
        return None

    @retry(**_RETRY)
    def get_active_realtors(self) -> List[Realtor]:
        all_rows = self._ws[self._cfg.sheet_realtors].get_all_values()
        results = []
        for i, row in enumerate(all_rows[1:], start=2):
            if len(row) > 7 and row[7] == RealtorStatus.ACTIVE.value:
                try:
                    results.append(Realtor.from_sheet_row(row, row_index=i))
                except Exception as e:
                    logger.warning(f"[repo] Риелтор строка {i}: {e}")
        return results

    @retry(**_RETRY)
    def update_realtor(self, realtor: Realtor) -> None:
        if realtor.row_index is None:
            return
        ws = self._ws[self._cfg.sheet_realtors]
        ws.update(
            f"A{realtor.row_index}",
            [realtor.to_sheet_row()],
            value_input_option="USER_ENTERED",
        )
        logger.info(f"[repo] Риелтор обновлён: {realtor.tg_id} → {realtor.status.value}")

    # ── Leads ─────────────────────────────────────────────────────────────────

    @retry(**_RETRY)
    def add_lead(self, lead: Lead) -> Lead:
        lead.external_id = str(uuid.uuid4())[:8].upper()
        self._ws[self._cfg.sheet_leads].append_row(
            lead.to_sheet_row(), value_input_option="USER_ENTERED"
        )
        logger.info(f"[repo] Заявка добавлена: {lead.external_id}")
        return lead

    @retry(**_RETRY)
    def get_new_leads(self) -> List[Lead]:
        all_rows = self._ws[self._cfg.sheet_leads].get_all_values()
        results = []
        for i, row in enumerate(all_rows[1:], start=2):
            if len(row) > 9 and row[9] == LeadStatus.NEW.value:
                try:
                    results.append(Lead(**self._lead_from_row(row, i)))
                except Exception as e:
                    logger.warning(f"[repo] Лид строка {i}: {e}")
        return results

    @staticmethod
    def _lead_from_row(row: List[str], row_index: int) -> dict:
        r = row + [""] * 15
        return dict(
            external_id=r[0], listing_external_id=r[1],
            tenant_tg_id=int(r[2]) if r[2].strip() else 0,
            tenant_name=r[3], tenant_phone=r[4], desired_date=r[5],
            budget=int(r[6]) if r[6].strip() else 0,
            district_pref=r[7], comment=r[8],
            status=LeadStatus(r[9]) if r[9] else LeadStatus.NEW,
            assigned_realtor_tg_id=int(r[10]) if r[10].strip() else None,
            assigned_at=datetime.fromisoformat(r[11]) if r[11].strip() else None,
            result_at=datetime.fromisoformat(r[12]) if r[12].strip() else None,
            created_at=datetime.fromisoformat(r[13]) if r[13].strip() else datetime.utcnow(),
            row_index=row_index,
        )

    @retry(**_RETRY)
    def update_lead_status(self, lead: Lead) -> None:
        if lead.row_index is None:
            return
        self._ws[self._cfg.sheet_leads].update(
            f"A{lead.row_index}",
            [lead.to_sheet_row()],
            value_input_option="USER_ENTERED",
        )

    # ── Settlements ───────────────────────────────────────────────────────────

    @retry(**_RETRY)
    def add_settlement(self, s: Settlement) -> Settlement:
        s.external_id = str(uuid.uuid4())[:8].upper()
        self._ws[self._cfg.sheet_settlements].append_row(
            s.to_sheet_row(), value_input_option="USER_ENTERED"
        )
        logger.info(
            f"[repo] Комиссия записана: {s.external_id} "
            f"риелтор={s.realtor_share}₸ платформа={s.platform_share}₸"
        )
        return s

    def refresh_caches(self) -> None:
        self._reload_caches()
