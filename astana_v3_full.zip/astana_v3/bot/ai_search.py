"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_v3/bot/ai_search.py"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import List, Optional

import httpx
from loguru import logger

# ── Filter schema (что Claude извлекает из запроса) ───────────────────────────

@dataclass
class SearchFilter:
    rooms:       Optional[int]   = None   # 0=студия, 1,2,3,4
    price_max:   Optional[int]   = None   # ₸/месяц
    price_min:   Optional[int]   = None
    district:    Optional[str]   = None   # район
    area_min:    Optional[float] = None   # м²
    area_max:    Optional[float] = None
    floor_min:   Optional[int]   = None
    amenities:   List[str]       = None   # ['Wi-Fi', 'парковка']
    keywords:    List[str]       = None   # свободный поиск по description

    def __post_init__(self):
        if self.amenities is None: self.amenities = []
        if self.keywords  is None: self.keywords  = []

    def to_human(self) -> str:
        parts = []
        if self.rooms is not None:
            parts.append("Студия" if self.rooms == 0 else f"{self.rooms}-комн.")
        if self.price_max:
            parts.append(f"до {self.price_max:,}₸".replace(",", " "))
        if self.price_min:
            parts.append(f"от {self.price_min:,}₸".replace(",", " "))
        if self.district:
            parts.append(f"район: {self.district}")
        if self.area_min:
            parts.append(f"от {self.area_min} м²")
        if self.amenities:
            parts.append(", ".join(self.amenities))
        return " · ".join(parts) if parts else "любые параметры"


# ── Claude API extractor ──────────────────────────────────────────────────────

EXTRACT_PROMPT = """\
Ты — AI-ассистент для поиска аренды квартир в Астане (Казахстан).
Пользователь написал запрос на аренду. Извлеки параметры поиска и верни ТОЛЬКО JSON.

Правила:
- rooms: 0=студия, 1/2/3/4 = количество комнат, null=не указано
- price_max / price_min: цена в тенге (₸), число без пробелов
- district: район Астаны если упомянут (Алматы, Есиль, Байконур, Сарыарка и др.)
- area_min / area_max: площадь м²
- floor_min: этаж (если "не первый" → floor_min=2)
- amenities: список из ["Wi-Fi","Кондиционер","Парковка","Балкон","Мебель","Техника","Лифт"]
- keywords: список ключевых слов для поиска по описанию

Пример запроса: "2 комнаты рядом с метро до 200 тысяч"
Пример ответа:
{"rooms":2,"price_max":200000,"district":null,"area_min":null,"area_max":null,"floor_min":null,"amenities":[],"keywords":["метро"]}

Запрос пользователя: {query}

Верни ТОЛЬКО JSON, без пояснений, без markdown.
"""


async def extract_filters(query: str, api_key: str) -> SearchFilter:
    """
    Отправляет запрос в Claude API и извлекает SearchFilter.
    Fallback: regex-парсер если API недоступен.
    """
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-haiku-4-5-20251001",  # Быстро + дёшево
                    "max_tokens": 256,
                    "messages": [{
                        "role": "user",
                        "content": EXTRACT_PROMPT.format(query=query),
                    }],
                },
            )
            resp.raise_for_status()
            data = resp.json()
            raw = data["content"][0]["text"].strip()
            # Убираем markdown-блоки если есть
            raw = re.sub(r"```(?:json)?|```", "", raw).strip()
            params = json.loads(raw)
            return SearchFilter(
                rooms       = params.get("rooms"),
                price_max   = params.get("price_max"),
                price_min   = params.get("price_min"),
                district    = params.get("district"),
                area_min    = params.get("area_min"),
                area_max    = params.get("area_max"),
                floor_min   = params.get("floor_min"),
                amenities   = params.get("amenities", []),
                keywords    = params.get("keywords", []),
            )
    except Exception as e:
        logger.warning(f"[ai_search] Claude API недоступен: {e}. Fallback regex.")
        return _regex_fallback(query)


def _regex_fallback(query: str) -> SearchFilter:
    """Простой regex-парсер — работает без API."""
    q = query.lower()
    sf = SearchFilter()

    # Комнаты
    if "студи" in q or "studio" in q: sf.rooms = 0
    elif m := re.search(r"(\d)\s*(?:-\s*)?комн", q): sf.rooms = int(m.group(1))
    elif "однуш" in q or "однокомн" in q: sf.rooms = 1
    elif "двушк" in q or "двухкомн" in q: sf.rooms = 2
    elif "трёшк" in q or "трехкомн" in q or "трёхкомн" in q: sf.rooms = 3

    # Цена
    price_words = {"тыс": 1000, "тысяч": 1000, "млн": 1_000_000, "миллион": 1_000_000}
    m = re.search(r"до\s*(\d[\d\s]*)\s*(тыс|тысяч|млн|миллион)?", q)
    if m:
        val = int(m.group(1).replace(" ", ""))
        mult = price_words.get(m.group(2) or "", 1)
        sf.price_max = val * mult if mult > 1 else val

    # Район
    districts = ["алматы", "есиль", "байконур", "сарыарка", "нура", "косшы"]
    for d in districts:
        if d in q:
            sf.district = d.capitalize()
            break

    # Этаж
    if "не первый" in q or "не 1" in q: sf.floor_min = 2
    if "высокий этаж" in q or "высокий" in q: sf.floor_min = 5

    # Удобства
    amenity_map = {
        "парковк": "Парковка", "wi-fi": "Wi-Fi", "вайфай": "Wi-Fi",
        "кондиц": "Кондиционер", "балкон": "Балкон",
        "мебл": "Мебель", "мебель": "Мебель",
        "лифт": "Лифт", "техник": "Техника",
    }
    for key, val in amenity_map.items():
        if key in q: sf.amenities.append(val)

    return sf


# ── Filter engine (применяет фильтры к списку объявлений) ────────────────────

def apply_filters(listings: list, sf: SearchFilter) -> list:
    """
    Фильтрует список Listing по SearchFilter.
    Возвращает отсортированный по релевантности список.
    """
    results = []
    for lst in listings:
        score = 0

        # Комнаты — жёсткий фильтр
        if sf.rooms is not None and lst.rooms != sf.rooms:
            continue

        # Цена
        if sf.price_max and lst.price > sf.price_max:
            continue
        if sf.price_min and lst.price < sf.price_min:
            continue

        # Район — мягкий (частичное совпадение)
        if sf.district:
            if lst.district and sf.district.lower() in lst.district.lower():
                score += 3
            elif lst.address and sf.district.lower() in lst.address.lower():
                score += 2
            # Не жёсткий отказ — просто меньше очков

        # Площадь
        if sf.area_min and lst.area and lst.area < sf.area_min:
            continue
        if sf.area_max and lst.area and lst.area > sf.area_max:
            continue

        # Этаж
        if sf.floor_min and lst.floor and lst.floor < sf.floor_min:
            continue

        # Удобства
        if sf.amenities:
            amenities_lower = (lst.amenities or "").lower()
            matched = sum(1 for a in sf.amenities if a.lower() in amenities_lower)
            score += matched * 2

        # Ключевые слова в описании
        if sf.keywords:
            desc_lower = ((lst.description or "") + " " + (lst.address or "")).lower()
            matched_kw = sum(1 for kw in sf.keywords if kw.lower() in desc_lower)
            score += matched_kw

        # Цена близко к максимуму = лучше
        if sf.price_max and lst.price:
            price_ratio = lst.price / sf.price_max
            if price_ratio <= 0.8:
                score += 1

        results.append((score, lst))

    results.sort(key=lambda x: (-x[0], x[1].price))
    return [lst for _, lst in results]


# ── Форматирование результатов ────────────────────────────────────────────────

def format_search_results(listings: list, sf: SearchFilter, bot_username: str) -> str:
    """Форматирует список результатов для отправки в Telegram."""
    if not listings:
        return (
            "😔 <b>Ничего не найдено</b>\n\n"
            f"Параметры поиска: {sf.to_human()}\n\n"
            "Попробуй изменить запрос. Например:\n"
            "• «1-комн до 150 тысяч Есиль»\n"
            "• «студия с парковкой»\n"
            "• «2 комнаты рядом с центром»"
        )

    header = f"🔍 <b>Найдено: {len(listings)} объявлений</b>\n"
    header += f"<i>{sf.to_human()}</i>\n"
    if len(listings) > 5:
        header += f"Показаны топ-5 из {len(listings)}\n"
    header += "\n"

    cards = []
    for i, lst in enumerate(listings[:5], 1):
        rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
        price_str   = f"{lst.price:,}".replace(",", " ") + " ₸/мес"
        card = (
            f"<b>{i}. {rooms_label}</b> · {price_str}\n"
            f"📍 {lst.district or ''} {lst.address or ''}".strip() + "\n"
        )
        if lst.area:
            card += f"📐 {lst.area:.0f} м²"
        if lst.floor and lst.total_floors:
            card += f" · {lst.floor}/{lst.total_floors} эт."
        card += "\n"
        if lst.amenities:
            card += f"✨ {lst.amenities[:50]}\n"
        # Кнопка-ссылка на объявление в канале (через message_id)
        cards.append(card.strip())

    return header + "\n\n".join(cards)
