"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_v3/bot/tenant_handlers.py"""

from __future__ import annotations

from aiogram import F, Router
from aiogram.enums import ParseMode
from aiogram.filters import CommandStart, Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
    WebAppInfo,
)
from loguru import logger

from bot.ai_search import apply_filters, extract_filters, format_search_results
from core.models import Lead, LeadStatus, ListingStatus
from sheets.repository import SheetRepo

router = Router()

# ── /start ────────────────────────────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(message: Message, cfg, miniapp_url: str) -> None:
    """Главное меню. Mini App открывается кнопкой Web App."""
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🏠 Открыть каталог квартир",
            web_app=WebAppInfo(url=miniapp_url),
        )],
        [
            InlineKeyboardButton(text="🔍 AI-поиск", callback_data="search:start"),
            InlineKeyboardButton(text="📋 Оставить заявку", callback_data="lead:new"),
        ],
        [InlineKeyboardButton(
            text="🏠 Разместить объявление",
            callback_data="landlord:start",
        )],
        [InlineKeyboardButton(
            text="🤝 Стать риелтором",
            callback_data="realtor:register",
        )],
    ])
    await message.answer(
        "🏙 <b>Аренда квартир в Астане</b>\n\n"
        "Свежие объявления от собственников — без посредников.\n\n"
        "✨ AI подберёт лучшие варианты по вашему запросу\n"
        "✨ Риелтор организует просмотр бесплатно\n"
        "✨ Каталог обновляется каждые 30 минут",
        reply_markup=kb,
        parse_mode=ParseMode.HTML,
    )


# ── AI Search ─────────────────────────────────────────────────────────────────

class SearchState(StatesGroup):
    waiting_query   = State()
    showing_results = State()


@router.callback_query(F.data == "search:start")
async def cb_search_start(cb: CallbackQuery, state: FSMContext) -> None:
    await cb.answer()
    await cb.message.answer(
        "🔍 <b>AI-поиск по объявлениям</b>\n\n"
        "Напиши что ищешь — я пойму естественный запрос:\n\n"
        "<i>«2-комн до 200к Есиль»\n"
        "«студия с балконом не первый этаж»\n"
        "«3 комнаты с парковкой до 400 тысяч»</i>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="search:cancel")],
        ]),
        parse_mode=ParseMode.HTML,
    )
    await state.set_state(SearchState.waiting_query)


@router.message(SearchState.waiting_query)
async def handle_search_query(
    message: Message,
    state: FSMContext,
    repo: SheetRepo,
    cfg,
) -> None:
    query = (message.text or "").strip()
    if not query or len(query) < 2:
        await message.answer("Пожалуйста, опишите что ищете:")
        return

    # Индикатор загрузки
    loading = await message.answer("🤖 AI анализирует запрос…")

    # Извлекаем фильтры через Claude API
    sf = await extract_filters(query, cfg.claude_api_key)

    # Получаем все опубликованные объявления
    all_listings = repo.get_posted_listings()

    # Применяем фильтры
    results = apply_filters(all_listings, sf)

    # Форматируем ответ
    text = format_search_results(results, sf, "")

    await loading.delete()

    if not results:
        await message.answer(text, parse_mode=ParseMode.HTML)
        await state.clear()
        return

    # Кнопки действий под результатами
    kb_rows = []
    for lst in results[:5]:
        rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
        price_str   = f"{lst.price:,}".replace(",", " ")
        kb_rows.append([InlineKeyboardButton(
            text=f"📅 {rooms_label} · {price_str}₸ — записаться",
            callback_data=f"lead:{lst.external_id}",
        )])

    kb_rows.append([
        InlineKeyboardButton(text="🔍 Новый поиск", callback_data="search:start"),
        InlineKeyboardButton(text="📋 Заявка риелтору", callback_data="lead:new"),
    ])

    await message.answer(
        text,
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows),
    )
    await state.update_data(last_results=[lst.external_id for lst in results[:5]])
    await state.set_state(SearchState.showing_results)


@router.callback_query(F.data == "search:cancel")
async def cb_search_cancel(cb: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await cb.answer()
    await cb.message.delete()


# ── Lead (запись на просмотр) ─────────────────────────────────────────────────

class LeadState(StatesGroup):
    name         = State()
    phone        = State()
    desired_date = State()
    confirm      = State()


@router.callback_query(F.data.startswith("lead:"))
async def cb_lead_start(cb: CallbackQuery, state: FSMContext) -> None:
    """Начинает сбор данных для заявки."""
    await cb.answer()
    listing_id = cb.data.split(":", 1)[1]
    if listing_id == "new":
        listing_id = ""

    await state.update_data(listing_id=listing_id)
    await cb.message.answer(
        "📅 <b>Запись на просмотр</b>\n\n"
        "Как вас зовут?",
        reply_markup=ReplyKeyboardRemove(),
        parse_mode=ParseMode.HTML,
    )
    await state.set_state(LeadState.name)


@router.message(LeadState.name)
async def lead_name(message: Message, state: FSMContext) -> None:
    await state.update_data(name=message.text.strip())
    await message.answer(
        "📞 Ваш номер телефона:",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[[KeyboardButton(text="📱 Поделиться", request_contact=True)]],
            resize_keyboard=True, one_time_keyboard=True,
        ),
    )
    await state.set_state(LeadState.phone)


@router.message(LeadState.phone, F.contact)
async def lead_phone_contact(message: Message, state: FSMContext) -> None:
    await state.update_data(phone=message.contact.phone_number)
    await _ask_date(message, state)


@router.message(LeadState.phone)
async def lead_phone_text(message: Message, state: FSMContext) -> None:
    await state.update_data(phone=message.text.strip())
    await _ask_date(message, state)


async def _ask_date(message: Message, state: FSMContext) -> None:
    await message.answer(
        "📆 Когда удобно посмотреть квартиру?",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="Сегодня"), KeyboardButton(text="Завтра")],
                [KeyboardButton(text="На этой неделе"), KeyboardButton(text="На следующей")],
            ],
            resize_keyboard=True, one_time_keyboard=True,
        ),
    )
    await state.set_state(LeadState.desired_date)


@router.message(LeadState.desired_date)
async def lead_date(message: Message, state: FSMContext) -> None:
    await state.update_data(desired_date=message.text.strip())
    data = await state.get_data()

    await message.answer(
        f"✅ <b>Подтвердите заявку:</b>\n\n"
        f"👤 {data['name']}\n"
        f"📞 {data['phone']}\n"
        f"📆 {data['desired_date']}",
        reply_markup=ReplyKeyboardMarkup(
            keyboard=[
                [KeyboardButton(text="✅ Подтвердить")],
                [KeyboardButton(text="❌ Отмена")],
            ],
            resize_keyboard=True, one_time_keyboard=True,
        ),
        parse_mode=ParseMode.HTML,
    )
    await state.set_state(LeadState.confirm)


@router.message(LeadState.confirm, F.text == "✅ Подтвердить")
async def lead_confirm(
    message: Message,
    state: FSMContext,
    repo: SheetRepo,
    cfg,
    bot,
) -> None:
    data = await state.get_data()
    await state.clear()

    lead = Lead(
        listing_external_id=data.get("listing_id", ""),
        tenant_tg_id=message.from_user.id,
        tenant_name=data.get("name", ""),
        tenant_phone=data.get("phone", ""),
        desired_date=data.get("desired_date", ""),
        status=LeadStatus.NEW,
    )

    try:
        lead = repo.add_lead(lead)
    except Exception as e:
        logger.error(f"[tenant] Ошибка сохранения лида: {e}")
        await message.answer("⚠️ Ошибка сохранения. Попробуй позже.",
                             reply_markup=ReplyKeyboardRemove())
        return

    await message.answer(
        f"🎉 <b>Заявка принята!</b>\n\n"
        f"ID заявки: <code>{lead.external_id}</code>\n\n"
        "С вами свяжется риелтор в течение 2 часов "
        "и согласует удобное время для просмотра. ✅",
        reply_markup=ReplyKeyboardRemove(),
        parse_mode=ParseMode.HTML,
    )

    # Уведомить всех активных риелторов (диспетчер)
    await _dispatch_lead(bot, repo, lead, cfg)


@router.message(LeadState.confirm, F.text == "❌ Отмена")
async def lead_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Заявка отменена.", reply_markup=ReplyKeyboardRemove())


# ── Диспетчер заявок ──────────────────────────────────────────────────────────

async def _dispatch_lead(bot, repo: SheetRepo, lead: Lead, cfg) -> None:
    """
    Назначает заявку лучшему доступному риелтору.
    Критерии: статус active + максимальный рейтинг + совпадение района.
    """
    realtors = repo.get_active_realtors()
    if not realtors:
        logger.warning(f"[dispatch] Нет активных риелторов для лида {lead.external_id}")
        # Уведомить администратора
        for admin_id in cfg.telegram.admin_ids:
            try:
                await bot.send_message(
                    admin_id,
                    f"⚠️ <b>Нет риелторов!</b> Лид {lead.external_id} не назначен.\n"
                    f"Клиент: {lead.tenant_name} · {lead.tenant_phone}",
                    parse_mode=ParseMode.HTML,
                )
            except Exception: pass
        return

    # Сортируем: выше рейтинг → меньше текущих заявок
    realtors.sort(key=lambda r: -r.rating)
    chosen = realtors[0]

    # Обновляем статус лида
    lead.status             = LeadStatus.ASSIGNED
    lead.assigned_realtor_tg_id = chosen.tg_id
    from datetime import datetime
    lead.assigned_at        = datetime.utcnow()
    repo.update_lead_status(lead)

    # Обновляем счётчик риелтора
    chosen.leads_total += 1
    repo.update_realtor(chosen)

    # Карточка заявки для риелтора
    listing_info = ""
    if lead.listing_external_id:
        lst = repo.get_listing_by_id(lead.listing_external_id)
        if lst:
            rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
            listing_info = (
                f"\n\n🏠 <b>Объект:</b> {rooms_label} · {lst.address}\n"
                f"💰 {lst.price:,}₸/мес".replace(",", " ")
            )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ Принял", callback_data=f"rl:accept:{lead.external_id}"),
            InlineKeyboardButton(text="❌ Отказать", callback_data=f"rl:decline:{lead.external_id}"),
        ],
        [InlineKeyboardButton(
            text=f"📞 {lead.tenant_phone}",
            url=f"https://t.me/+{lead.tenant_phone.replace('+','').replace(' ','')}",
        )],
    ])

    try:
        await bot.send_message(
            chat_id=chosen.tg_id,
            text=(
                f"📋 <b>Новая заявка на просмотр!</b>\n\n"
                f"👤 Клиент: {lead.tenant_name}\n"
                f"📞 {lead.tenant_phone}\n"
                f"📆 Желаемое время: {lead.desired_date}"
                f"{listing_info}\n\n"
                f"⚡️ Лид ID: <code>{lead.external_id}</code>\n"
                f"Свяжитесь с клиентом в течение <b>2 часов</b>!"
            ),
            reply_markup=kb,
            parse_mode=ParseMode.HTML,
        )
        logger.info(f"[dispatch] Лид {lead.external_id} назначен риелтору {chosen.tg_id}")
    except Exception as e:
        logger.error(f"[dispatch] Не удалось отправить риелтору {chosen.tg_id}: {e}")


# ── Риелтор: принять/отклонить заявку ────────────────────────────────────────

@router.callback_query(F.data.startswith("rl:accept:"))
async def cb_realtor_accept(cb: CallbackQuery, repo: SheetRepo) -> None:
    lead_id = cb.data.split(":", 2)[2]
    await cb.answer("✅ Заявка принята!")
    await cb.message.edit_reply_markup(reply_markup=InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(
            text="🏁 Отметить результат",
            callback_data=f"rl:result:{lead_id}",
        )],
    ]))


@router.callback_query(F.data.startswith("rl:result:"))
async def cb_realtor_result(cb: CallbackQuery) -> None:
    lead_id = cb.data.split(":", 2)[2]
    await cb.answer()
    await cb.message.answer(
        "📊 Каков результат просмотра?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎉 Квартира сдана!", callback_data=f"rl:rented:{lead_id}")],
            [InlineKeyboardButton(text="😔 Не подошло", callback_data=f"rl:nomatch:{lead_id}")],
            [InlineKeyboardButton(text="❌ Клиент отменил", callback_data=f"rl:cancelled:{lead_id}")],
        ]),
    )


@router.callback_query(F.data.startswith("rl:rented:"))
async def cb_realtor_rented(
    cb: CallbackQuery,
    repo: SheetRepo,
    cfg,
    bot,
) -> None:
    """Риелтор нажал «Сдано» → запускаем флоу комиссии."""
    lead_id = cb.data.split(":", 2)[2]
    await cb.answer("🎉 Отлично!")

    # Запрашиваем фото договора
    await cb.message.answer(
        "🎉 <b>Поздравляем со сделкой!</b>\n\n"
        "Пришлите фото договора аренды для расчёта комиссии.\n"
        "Укажите также месячную сумму аренды (в тенге):",
        parse_mode=ParseMode.HTML,
    )
    # Дальнейший флоу обрабатывается в commission_fsm.py


@router.callback_query(F.data.startswith("rl:decline:"))
async def cb_realtor_decline(cb: CallbackQuery, repo: SheetRepo, cfg, bot) -> None:
    await cb.answer("Заявка передана другому риелтору")
    # TODO: переназначить следующему риелтору по рейтингу
    await cb.message.edit_reply_markup(reply_markup=None)


# ── Похожие объявления (из inline кнопок канала) ──────────────────────────────

@router.callback_query(F.data.startswith("similar:"))
async def cb_similar(cb: CallbackQuery, repo: SheetRepo) -> None:
    await cb.answer()
    parts    = cb.data.split(":")
    rooms    = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None
    district = parts[2] if len(parts) > 2 else ""

    all_posted = repo.get_posted_listings()
    results = []
    for lst in all_posted:
        score = 0
        if rooms is not None and lst.rooms == rooms: score += 3
        if district and lst.district and district.lower() in lst.district.lower(): score += 2
        if score > 0: results.append((score, lst))

    results.sort(key=lambda x: -x[0])
    similar = [lst for _, lst in results[:5]]

    if not similar:
        await cb.message.answer("😔 Похожих объявлений пока нет. Новые появляются каждый час!")
        return

    lines = [f"🔍 <b>Похожие объявления ({len(similar)}):</b>\n"]
    for lst in similar:
        rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
        price_str   = f"{lst.price:,}".replace(",", " ")
        lines.append(f"• {rooms_label} · {price_str}₸ · {lst.district or lst.address}")

    await cb.message.answer(
        "\n".join(lines),
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🔍 AI-поиск", callback_data="search:start"),
            InlineKeyboardButton(text="📋 Оставить заявку", callback_data="lead:new"),
        ]]),
    )
