"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_bot_v2/bot/landlord_fsm.py"""

from __future__ import annotations

from typing import List

from aiogram import F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    Message,
    ReplyKeyboardMarkup,
    ReplyKeyboardRemove,
)
from loguru import logger

from core.models import Listing, ListingStatus
from sheets.repository import SheetRepo

router = Router()

# ── Константы ─────────────────────────────────────────────────────────────────

DISTRICTS = [
    "Алматы", "Есиль", "Байконур", "Сарыарка",
    "Нура", "Косшы (пригород)", "Другой",
]

ROOMS_OPTIONS = ["Студия", "1", "2", "3", "4+"]

AMENITIES_OPTIONS = [
    "Wi-Fi", "Кондиционер", "Стиральная машина", "Посудомойка",
    "Парковка", "Лифт", "Балкон", "Мебель", "Техника", "Охрана",
]

SKIP_TEXT = "⏭ Пропустить"
DONE_TEXT  = "✅ Готово"
CANCEL_TEXT = "❌ Отмена"


# ── FSM States ────────────────────────────────────────────────────────────────

class LandlordForm(StatesGroup):
    name         = State()
    phone        = State()
    district     = State()
    address      = State()
    rooms        = State()
    area         = State()
    floor        = State()
    price        = State()
    deposit      = State()
    contract     = State()
    amenities    = State()
    description  = State()
    photos       = State()
    confirm      = State()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _kb(*rows: list[str], one_time: bool = True) -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=t) for t in row] for row in rows],
        resize_keyboard=True,
        one_time_keyboard=one_time,
    )


def _inline(*rows: list[tuple[str, str]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=t, callback_data=d) for t, d in row]
            for row in rows
        ]
    )


async def _cancel(msg: Message, state: FSMContext) -> None:
    await state.clear()
    await msg.answer(
        "Анкета отменена. Напиши /addlisting чтобы начать заново.",
        reply_markup=ReplyKeyboardRemove(),
    )


def _progress(step: int, total: int = 13) -> str:
    filled = "▓" * step
    empty  = "░" * (total - step)
    return f"[{filled}{empty}] {step}/{total}"


def _summary(data: dict) -> str:
    rooms_label = "Студия" if data.get("rooms") == 0 else f"{data.get('rooms', '?')}-комн."
    lines = [
        f"🏙 <b>{rooms_label} · {data.get('area', '?')} м² · {data.get('floor', '?')} эт.</b>",
        f"📍 {data.get('district', '?')}, {data.get('address', '?')}",
        f"💰 {int(data.get('price', 0)):,}".replace(",", " ") + " ₸/мес",
        f"🔑 Депозит: {data.get('deposit', '?')} | Договор: {data.get('contract', '?')}",
        f"📞 {data.get('name', '?')} · {data.get('phone', '?')}",
    ]
    amenities = data.get("amenities", [])
    if amenities:
        lines.append(f"✨ {', '.join(amenities)}")
    desc = data.get("description", "")
    if desc:
        lines.append(f"\n{desc[:200]}")
    photos = data.get("photos", [])
    lines.append(f"\n📸 Фото: {len(photos)} шт.")
    return "\n".join(lines)


# ── Entry Point ───────────────────────────────────────────────────────────────

@router.message(Command("addlisting"))
async def cmd_addlisting(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "🏠 <b>Добавление объявления об аренде</b>\n\n"
        "Я задам несколько вопросов — это займёт около 3 минут.\n"
        "Для отмены напиши /cancel в любой момент.\n\n"
        f"{_progress(0)}\n\n"
        "Как вас зовут? (имя или ФИО)",
        reply_markup=ReplyKeyboardRemove(),
        parse_mode=ParseMode.HTML,
    )
    await state.set_state(LandlordForm.name)


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    await _cancel(message, state)


# ── Step 1: Имя ───────────────────────────────────────────────────────────────

@router.message(LandlordForm.name)
async def step_name(message: Message, state: FSMContext) -> None:
    if not message.text or len(message.text.strip()) < 2:
        await message.answer("Введите ваше имя (минимум 2 символа):")
        return
    await state.update_data(name=message.text.strip())
    await message.answer(
        f"{_progress(1)}\n\n📞 Укажите ваш номер телефона:\n"
        "(например: +7 777 123 45 67)",
        reply_markup=_kb([KeyboardButton(
            text="📱 Поделиться контактом",
            request_contact=True,
        )]),
    )
    await state.set_state(LandlordForm.phone)


# ── Step 2: Телефон ───────────────────────────────────────────────────────────

@router.message(LandlordForm.phone, F.contact)
async def step_phone_contact(message: Message, state: FSMContext) -> None:
    phone = message.contact.phone_number
    await state.update_data(phone=phone)
    await _ask_district(message, state)


@router.message(LandlordForm.phone)
async def step_phone_text(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if len(text) < 7:
        await message.answer("Введите корректный номер телефона:")
        return
    await state.update_data(phone=text)
    await _ask_district(message, state)


async def _ask_district(message: Message, state: FSMContext) -> None:
    rows = [[d] for d in DISTRICTS[:4]] + [[DISTRICTS[4], DISTRICTS[5]], [DISTRICTS[6]]]
    await message.answer(
        f"{_progress(2)}\n\n📍 Выберите район:",
        reply_markup=_kb(*[[d] for d in DISTRICTS]),
    )
    await state.set_state(LandlordForm.district)


# ── Step 3: Район ─────────────────────────────────────────────────────────────

@router.message(LandlordForm.district)
async def step_district(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    await state.update_data(district=text)
    await message.answer(
        f"{_progress(3)}\n\n🏢 Введите точный адрес:\n"
        "(улица, дом, ЖК — например: ул. Достык 1, ЖК Нур-Сити)",
        reply_markup=ReplyKeyboardRemove(),
    )
    await state.set_state(LandlordForm.address)


# ── Step 4: Адрес ─────────────────────────────────────────────────────────────

@router.message(LandlordForm.address)
async def step_address(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if len(text) < 5:
        await message.answer("Введите адрес подробнее:")
        return
    await state.update_data(address=text)
    await message.answer(
        f"{_progress(4)}\n\n🛏 Количество комнат:",
        reply_markup=_kb(ROOMS_OPTIONS[:3], ROOMS_OPTIONS[3:]),
    )
    await state.set_state(LandlordForm.rooms)


# ── Step 5: Комнаты ───────────────────────────────────────────────────────────

@router.message(LandlordForm.rooms)
async def step_rooms(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    if text == "Студия":
        rooms = 0
    elif text == "4+":
        rooms = 4
    elif text.isdigit():
        rooms = int(text)
    else:
        await message.answer("Выберите из вариантов:")
        return
    await state.update_data(rooms=rooms)
    await message.answer(
        f"{_progress(5)}\n\n📐 Площадь квартиры (м²):\n(например: 45)",
        reply_markup=ReplyKeyboardRemove(),
    )
    await state.set_state(LandlordForm.area)


# ── Step 6: Площадь ──────────────────────────────────────────────────────────

@router.message(LandlordForm.area)
async def step_area(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip().replace(",", ".")
    try:
        area = float(text)
        assert 10 < area < 1000
    except (ValueError, AssertionError):
        await message.answer("Введите площадь числом (например: 45):")
        return
    await state.update_data(area=area)
    await message.answer(
        f"{_progress(6)}\n\n🏢 Этаж / из скольки?\n(например: 5/9 или просто 5)",
        reply_markup=_kb([SKIP_TEXT]),
    )
    await state.set_state(LandlordForm.floor)


# ── Step 7: Этаж ─────────────────────────────────────────────────────────────

@router.message(LandlordForm.floor)
async def step_floor(message: Message, state: FSMContext) -> None:
    text = (message.text or "").strip()
    floor = total_floors = None
    if text != SKIP_TEXT:
        parts = text.replace(" ", "").split("/")
        try:
            floor = int(parts[0])
            total_floors = int(parts[1]) if len(parts) > 1 else None
        except (ValueError, IndexError):
            pass
    await state.update_data(floor=floor, total_floors=total_floors)
    await message.answer(
        f"{_progress(7)}\n\n💰 Цена аренды в месяц (тенге):\n(например: 150000)",
        reply_markup=ReplyKeyboardRemove(),
    )
    await state.set_state(LandlordForm.price)


# ── Step 8: Цена ─────────────────────────────────────────────────────────────

@router.message(LandlordForm.price)
async def step_price(message: Message, state: FSMContext) -> None:
    text = (message.text or "").replace(" ", "").replace(",", "")
    try:
        price = int(text)
        assert 10_000 <= price <= 50_000_000
    except (ValueError, AssertionError):
        await message.answer("Введите сумму числом в тенге (например: 150000):")
        return
    await state.update_data(price=price)
    await message.answer(
        f"{_progress(8)}\n\n🔑 Депозит:",
        reply_markup=_kb(["Нет депозита", "1 месяц", "2 месяца", "Другое"]),
    )
    await state.set_state(LandlordForm.deposit)


# ── Step 9: Депозит ───────────────────────────────────────────────────────────

@router.message(LandlordForm.deposit)
async def step_deposit(message: Message, state: FSMContext) -> None:
    await state.update_data(deposit=(message.text or "").strip())
    await message.answer(
        f"{_progress(9)}\n\n📄 Срок договора аренды:",
        reply_markup=_kb(["1 месяц", "3-6 месяцев", "6-12 месяцев", "Любой"]),
    )
    await state.set_state(LandlordForm.contract)


# ── Step 10: Срок договора ────────────────────────────────────────────────────

@router.message(LandlordForm.contract)
async def step_contract(message: Message, state: FSMContext) -> None:
    await state.update_data(contract=(message.text or "").strip())

    # Формируем кнопки удобств (мультивыбор через InlineKeyboard)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=a, callback_data=f"amenity:{a}")
            for a in AMENITIES_OPTIONS[i:i+2]
        ]
        for i in range(0, len(AMENITIES_OPTIONS), 2)
    ] + [[InlineKeyboardButton(text=DONE_TEXT, callback_data="amenity:done")]])

    await state.update_data(amenities=[])
    await message.answer(
        f"{_progress(10)}\n\n✨ Выберите удобства (можно несколько):\n"
        "Нажмите на каждое нужное, потом ✅ Готово",
        reply_markup=ReplyKeyboardRemove(),
    )
    await message.answer("Удобства:", reply_markup=kb)
    await state.set_state(LandlordForm.amenities)


# ── Step 10b: Удобства (inline мультивыбор) ───────────────────────────────────

@router.callback_query(LandlordForm.amenities, F.data.startswith("amenity:"))
async def step_amenities_cb(cb: CallbackQuery, state: FSMContext) -> None:
    value = cb.data.split(":", 1)[1]
    data = await state.get_data()
    amenities: List[str] = data.get("amenities", [])

    if value == "done":
        await cb.answer()
        await cb.message.edit_reply_markup(reply_markup=None)
        # Показываем выбранное
        selected = ", ".join(amenities) if amenities else "ничего не выбрано"
        await cb.message.answer(
            f"✅ Выбрано: {selected}\n\n"
            f"{_progress(11)}\n\n📝 Напишите описание квартиры:\n"
            "(максимум 500 символов, или пропустите)",
            reply_markup=_kb([SKIP_TEXT]),
        )
        await state.set_state(LandlordForm.description)
        return

    # Toggle выбора
    if value in amenities:
        amenities.remove(value)
        await cb.answer(f"Убрано: {value}")
    else:
        amenities.append(value)
        await cb.answer(f"Добавлено: {value}")

    await state.update_data(amenities=amenities)

    # Обновляем кнопки (отмечаем выбранные ✓)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(
                text=("✓ " if a in amenities else "") + a,
                callback_data=f"amenity:{a}",
            )
            for a in AMENITIES_OPTIONS[i:i+2]
        ]
        for i in range(0, len(AMENITIES_OPTIONS), 2)
    ] + [[InlineKeyboardButton(text=DONE_TEXT, callback_data="amenity:done")]])
    await cb.message.edit_reply_markup(reply_markup=kb)


# ── Step 11: Описание ─────────────────────────────────────────────────────────

@router.message(LandlordForm.description)
async def step_description(message: Message, state: FSMContext) -> None:
    text = "" if message.text == SKIP_TEXT else (message.text or "").strip()[:500]
    await state.update_data(description=text)
    await message.answer(
        f"{_progress(12)}\n\n📸 Загрузите фото квартиры:\n\n"
        "• Отправьте до <b>10 фотографий</b>\n"
        "• Когда загрузите все — нажмите «Готово»\n"
        "• Первое фото будет главным",
        reply_markup=_kb([DONE_TEXT]),
        parse_mode=ParseMode.HTML,
    )
    await state.update_data(photos=[])
    await state.set_state(LandlordForm.photos)


# ── Step 12: Фото ─────────────────────────────────────────────────────────────

@router.message(LandlordForm.photos, F.photo)
async def step_photo_receive(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    photos: List[str] = data.get("photos", [])
    if len(photos) >= 10:
        await message.answer("Максимум 10 фото. Нажмите «Готово».")
        return
    # Берём наибольшее разрешение
    file_id = message.photo[-1].file_id
    photos.append(file_id)
    await state.update_data(photos=photos)
    count = len(photos)
    await message.answer(
        f"✅ Фото {count}/10 получено."
        + (" Нажмите «Готово» когда закончите." if count == 1 else ""),
        reply_markup=_kb([DONE_TEXT]),
    )


@router.message(LandlordForm.photos, F.text == DONE_TEXT)
async def step_photos_done(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    photos = data.get("photos", [])
    if not photos:
        await message.answer("Пожалуйста, загрузите хотя бы одно фото:")
        return
    await _show_confirmation(message, state, data)


async def _show_confirmation(message: Message, state: FSMContext, data: dict) -> None:
    summary = _summary(data)
    await message.answer(
        f"{_progress(13)}\n\n"
        "📋 <b>Проверьте объявление:</b>\n\n"
        f"{summary}\n\n"
        "Всё верно?",
        reply_markup=_kb(["✅ Отправить на проверку", "❌ Начать заново"]),
        parse_mode=ParseMode.HTML,
    )
    await state.set_state(LandlordForm.confirm)


# ── Step 13: Подтверждение ────────────────────────────────────────────────────

@router.message(LandlordForm.confirm, F.text == "✅ Отправить на проверку")
async def step_confirm_yes(
    message: Message,
    state: FSMContext,
    repo: SheetRepo,
    admin_ids: list,
    bot,
) -> None:
    data = await state.get_data()
    await state.clear()

    listing = Listing(
        landlord_tg_id=message.from_user.id,
        landlord_username=f"@{message.from_user.username}" if message.from_user.username else "",
        landlord_name=data.get("name", ""),
        landlord_phone=data.get("phone", ""),
        district=data.get("district", ""),
        address=data.get("address", ""),
        rooms=data.get("rooms"),
        area=data.get("area"),
        floor=data.get("floor"),
        total_floors=data.get("total_floors"),
        price=data.get("price", 0),
        deposit=data.get("deposit", ""),
        contract_months=data.get("contract", ""),
        amenities=", ".join(data.get("amenities", [])),
        description=data.get("description", ""),
        photos=data.get("photos", []),
        status=ListingStatus.PENDING,
    )

    try:
        listing = repo.add_listing(listing)
    except Exception as e:
        logger.error(f"[landlord_fsm] Ошибка сохранения: {e}")
        await message.answer(
            "⚠️ Произошла ошибка при сохранении. Попробуйте позже.",
            reply_markup=ReplyKeyboardRemove(),
        )
        return

    await message.answer(
        f"🎉 <b>Объявление отправлено на проверку!</b>\n\n"
        f"ID: <code>{listing.external_id}</code>\n\n"
        "Обычно проверка занимает до 2 часов. "
        "После одобрения объявление появится в канале.\n\n"
        "Вы получите уведомление когда оно будет опубликовано. ✅",
        reply_markup=ReplyKeyboardRemove(),
        parse_mode=ParseMode.HTML,
    )

    # Уведомление всем администраторам
    await _notify_admins(bot, admin_ids, listing)
    logger.info(f"[landlord_fsm] Объявление создано: {listing.external_id} от {message.from_user.id}")


@router.message(LandlordForm.confirm, F.text == "❌ Начать заново")
async def step_confirm_restart(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(
        "Анкета сброшена. Напиши /addlisting чтобы начать заново.",
        reply_markup=ReplyKeyboardRemove(),
    )


# ── Уведомление администратора ────────────────────────────────────────────────

async def _notify_admins(bot, admin_ids: list, listing: Listing) -> None:
    """Отправляет модераторам карточку с кнопками Одобрить/Отклонить."""
    rooms_label = "Студия" if listing.rooms == 0 else f"{listing.rooms}-комн."
    text = (
        f"🆕 <b>Новое объявление на модерацию</b>\n\n"
        f"ID: <code>{listing.external_id}</code>\n"
        f"Тип: {rooms_label} · {listing.area} м²\n"
        f"Район: {listing.district}\n"
        f"Адрес: {listing.address}\n"
        f"Цена: {listing.price:,}₸/мес\n".replace(",", " ") +
        f"Депозит: {listing.deposit}\n"
        f"Договор: {listing.contract_months}\n"
        f"Автор: {listing.landlord_name} · {listing.landlord_phone}\n"
        f"TG: {listing.landlord_username}\n"
        f"Фото: {len(listing.photos)} шт."
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="✅ Одобрить",
            callback_data=f"mod:approve:{listing.external_id}",
        ),
        InlineKeyboardButton(
            text="❌ Отклонить",
            callback_data=f"mod:reject:{listing.external_id}",
        ),
    ]])

    for admin_id in admin_ids:
        try:
            # Если есть фото — отправляем первое
            if listing.photos:
                await bot.send_photo(
                    chat_id=admin_id,
                    photo=listing.photos[0],
                    caption=text,
                    reply_markup=kb,
                    parse_mode=ParseMode.HTML,
                )
            else:
                await bot.send_message(
                    chat_id=admin_id,
                    text=text,
                    reply_markup=kb,
                    parse_mode=ParseMode.HTML,
                )
        except Exception as e:
            logger.error(f"[landlord_fsm] Не удалось уведомить админа {admin_id}: {e}")
