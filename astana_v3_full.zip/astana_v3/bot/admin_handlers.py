"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_bot_v2/bot/admin_handlers.py"""

from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.enums import ParseMode
from aiogram.filters import Command
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from loguru import logger

from core.config import AppConfig
from core.models import ListingStatus, RealtorStatus
from sheets.repository import SheetRepo

router = Router()


def _is_admin(user_id: int, cfg: AppConfig) -> bool:
    return user_id in cfg.telegram.admin_ids


# ── Статистика ────────────────────────────────────────────────────────────────

@router.message(Command("stats"))
async def cmd_stats(message: Message, repo: SheetRepo, cfg: AppConfig) -> None:
    if not _is_admin(message.from_user.id, cfg):
        return

    pending  = repo.get_pending_listings()
    approved = repo.get_approved_listings()
    posted   = repo.get_posted_listings()
    realtors = repo.get_active_realtors()

    await message.answer(
        "📊 <b>Статистика платформы</b>\n\n"
        f"🕐 На модерации: <b>{len(pending)}</b>\n"
        f"✅ Одобрено (в очереди): <b>{len(approved)}</b>\n"
        f"📢 Опубликовано: <b>{len(posted)}</b>\n"
        f"🤝 Активных риелторов: <b>{len(realtors)}</b>\n\n"
        "Команды:\n"
        "/pending — список на модерации\n"
        "/realtors — управление риелторами",
        parse_mode=ParseMode.HTML,
    )


@router.message(Command("pending"))
async def cmd_pending(message: Message, repo: SheetRepo, cfg: AppConfig) -> None:
    if not _is_admin(message.from_user.id, cfg):
        return

    listings = repo.get_pending_listings()
    if not listings:
        await message.answer("✅ Нет объявлений на модерации")
        return

    for lst in listings[:5]:  # Показываем по 5 за раз
        rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
        text = (
            f"📋 <b>ID: {lst.external_id}</b>\n"
            f"{rooms_label} · {lst.area} м² · {lst.district}\n"
            f"{lst.address}\n"
            f"💰 {lst.price:,}₸/мес\n".replace(",", " ") +
            f"👤 {lst.landlord_name} · {lst.landlord_phone}\n"
            f"📸 {len(lst.photos)} фото"
        )
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Одобрить", callback_data=f"mod:approve:{lst.external_id}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"mod:reject:{lst.external_id}"),
        ]])
        if lst.photos:
            await message.answer_photo(lst.photos[0], caption=text, reply_markup=kb, parse_mode=ParseMode.HTML)
        else:
            await message.answer(text, reply_markup=kb, parse_mode=ParseMode.HTML)


# ── Колбэки модерации ─────────────────────────────────────────────────────────

@router.callback_query(F.data.startswith("mod:approve:"))
async def cb_approve(cb: CallbackQuery, repo: SheetRepo, cfg: AppConfig, bot: Bot) -> None:
    if not _is_admin(cb.from_user.id, cfg):
        await cb.answer("Нет доступа", show_alert=True)
        return

    external_id = cb.data.split(":", 2)[2]
    listing = repo.get_listing_by_id(external_id)
    if not listing:
        await cb.answer("Объявление не найдено", show_alert=True)
        return
    if listing.status != ListingStatus.PENDING:
        await cb.answer(f"Статус уже: {listing.status.value}", show_alert=True)
        return

    repo.update_listing_status(listing, ListingStatus.APPROVED)

    await cb.answer("✅ Одобрено!")
    await cb.message.edit_caption(
        caption=(cb.message.caption or cb.message.text or "") + "\n\n✅ <b>ОДОБРЕНО</b>",
        reply_markup=None,
        parse_mode=ParseMode.HTML,
    )

    # Уведомление арендодателю
    try:
        await bot.send_message(
            chat_id=listing.landlord_tg_id,
            text=(
                f"🎉 <b>Ваше объявление одобрено!</b>\n\n"
                f"ID: <code>{listing.external_id}</code>\n\n"
                "Оно будет опубликовано в канале в ближайшее время.\n"
                "Когда ваша квартира будет сдана — напишите нам, "
                "чтобы мы убрали объявление. Команда: /rented"
            ),
            parse_mode=ParseMode.HTML,
        )
    except Exception as e:
        logger.warning(f"[admin] Не удалось уведомить арендодателя {listing.landlord_tg_id}: {e}")

    logger.info(f"[admin] Одобрено: {external_id} администратором {cb.from_user.id}")


@router.callback_query(F.data.startswith("mod:reject:"))
async def cb_reject(cb: CallbackQuery, repo: SheetRepo, cfg: AppConfig, bot: Bot) -> None:
    if not _is_admin(cb.from_user.id, cfg):
        await cb.answer("Нет доступа", show_alert=True)
        return

    external_id = cb.data.split(":", 2)[2]
    listing = repo.get_listing_by_id(external_id)
    if not listing:
        await cb.answer("Не найдено", show_alert=True)
        return

    repo.update_listing_status(listing, ListingStatus.REJECTED)
    await cb.answer("❌ Отклонено")
    await cb.message.edit_caption(
        caption=(cb.message.caption or cb.message.text or "") + "\n\n❌ <b>ОТКЛОНЕНО</b>",
        reply_markup=None,
        parse_mode=ParseMode.HTML,
    )

    try:
        await bot.send_message(
            chat_id=listing.landlord_tg_id,
            text=(
                "😔 К сожалению, ваше объявление не прошло модерацию.\n"
                "Проверьте что все фото чёткие и адрес указан корректно.\n"
                "Попробуйте снова: /addlisting"
            ),
        )
    except Exception as e:
        logger.warning(f"[admin] Уведомление арендодателю: {e}")


# ── Команда /rented (арендодатель отмечает «сдано») ──────────────────────────

@router.message(Command("rented"))
async def cmd_rented(message: Message, repo: SheetRepo, bot: Bot) -> None:
    """Арендодатель сообщает что квартира сдана — объявление снимается."""
    user_id = message.from_user.id

    # Ищем его активные объявления
    posted = repo.get_posted_listings()
    mine = [lst for lst in posted if lst.landlord_tg_id == user_id]

    if not mine:
        await message.answer(
            "У вас нет активных объявлений. "
            "Если хотите добавить новое — /addlisting"
        )
        return

    if len(mine) == 1:
        listing = mine[0]
        repo.update_listing_status(listing, ListingStatus.RENTED)
        await message.answer(
            f"✅ Отлично! Объявление <code>{listing.external_id}</code> снято.\n"
            "Поздравляем с успешной сдачей! 🎉\n\n"
            "Хотите разместить другую квартиру? /addlisting",
            parse_mode=ParseMode.HTML,
        )
        logger.info(f"[admin] Сдано арендодателем: {listing.external_id}")
        return

    # Несколько объявлений — выбор
    kb_rows = []
    for lst in mine:
        rooms_label = "Студия" if lst.rooms == 0 else f"{lst.rooms}-комн."
        kb_rows.append([InlineKeyboardButton(
            text=f"{lst.external_id} · {rooms_label} · {lst.address[:25]}",
            callback_data=f"rented:{lst.external_id}",
        )])

    await message.answer(
        "Какое из ваших объявлений было сдано?",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_rows),
    )


@router.callback_query(F.data.startswith("rented:"))
async def cb_rented(cb: CallbackQuery, repo: SheetRepo) -> None:
    external_id = cb.data.split(":", 1)[1]
    listing = repo.get_listing_by_id(external_id)
    if not listing:
        await cb.answer("Не найдено", show_alert=True)
        return
    if listing.landlord_tg_id != cb.from_user.id:
        await cb.answer("Это не ваше объявление", show_alert=True)
        return

    repo.update_listing_status(listing, ListingStatus.RENTED)
    await cb.answer("✅ Снято с публикации!")
    await cb.message.edit_text(
        f"✅ Объявление <code>{external_id}</code> снято. Поздравляем с успешной сдачей! 🎉",
        parse_mode=ParseMode.HTML,
    )
    logger.info(f"[admin] Сдано (callback): {external_id}")
