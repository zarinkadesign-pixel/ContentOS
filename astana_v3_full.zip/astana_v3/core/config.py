"""NOESIS — Deterministic Hybrid Control Framework for Frozen Neural Operators (DHCF-FNO)
Copyright (c) 2026 AMAImedia.com
All rights reserved. astana_bot_v2/core/config.py"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

from dotenv import load_dotenv

load_dotenv()


def _req(key: str) -> str:
    v = os.getenv(key)
    if not v:
        raise EnvironmentError(f"Required env var '{key}' not set")
    return v


def _opt(key: str, default: str = "") -> str:
    return os.getenv(key, default)


@dataclass(frozen=True)
class TelegramConfig:
    bot_token: str               = field(default_factory=lambda: _req("BOT_TOKEN"))
    channel_id: str              = field(default_factory=lambda: _req("CHANNEL_ID"))
    admin_ids: List[int]         = field(default_factory=lambda: [
        int(x) for x in _opt("ADMIN_IDS", "").split(",") if x.strip()
    ])
    realtor_username: str        = field(default_factory=lambda: _opt("REALTOR_USERNAME", "@realtor"))
    moderation_chat_id: str      = field(default_factory=lambda: _opt("MODERATION_CHAT_ID", ""))


@dataclass(frozen=True)
class SheetsConfig:
    service_account_json: Path   = field(
        default_factory=lambda: Path(_opt("GOOGLE_SERVICE_ACCOUNT_JSON", "secrets/service_account.json"))
    )
    spreadsheet_id: str          = field(default_factory=lambda: _req("SPREADSHEET_ID"))
    sheet_listings: str          = field(default_factory=lambda: _opt("SHEET_LISTINGS", "listings"))
    sheet_realtors: str          = field(default_factory=lambda: _opt("SHEET_REALTORS", "realtors"))
    sheet_leads: str             = field(default_factory=lambda: _opt("SHEET_LEADS", "leads"))
    sheet_settlements: str       = field(default_factory=lambda: _opt("SHEET_SETTLEMENTS", "settlements"))


@dataclass(frozen=True)
class SchedulerConfig:
    # Рандомный интервал между постами (минуты)
    post_interval_min: int       = field(default_factory=lambda: int(_opt("POST_INTERVAL_MIN", "60")))
    post_interval_max: int       = field(default_factory=lambda: int(_opt("POST_INTERVAL_MAX", "240")))
    # Активные часы (UTC+5 = Астана)
    active_hour_start: int       = field(default_factory=lambda: int(_opt("ACTIVE_HOUR_START", "9")))
    active_hour_end: int         = field(default_factory=lambda: int(_opt("ACTIVE_HOUR_END", "21")))
    # Повторная публикация одного объявления (часы)
    repost_interval_hours: int   = field(default_factory=lambda: int(_opt("REPOST_INTERVAL_HOURS", "24")))
    max_posts_per_day: int       = field(default_factory=lambda: int(_opt("MAX_POSTS_PER_DAY", "30")))
    post_delay_seconds: float    = field(default_factory=lambda: float(_opt("POST_DELAY_SECONDS", "3")))


@dataclass(frozen=True)
class RealtorConfig:
    commission_rate: float       = field(default_factory=lambda: float(_opt("COMMISSION_RATE", "0.5")))
    platform_pct: float          = field(default_factory=lambda: float(_opt("PLATFORM_PCT", "0.60")))
    realtor_pct: float           = field(default_factory=lambda: float(_opt("REALTOR_PCT", "0.40")))
    # Правила нарушений
    freeze_on_violation: int     = field(default_factory=lambda: int(_opt("FREEZE_ON_VIOLATION", "2")))
    ban_on_violation: int        = field(default_factory=lambda: int(_opt("BAN_ON_VIOLATION", "3")))
    freeze_days: int             = field(default_factory=lambda: int(_opt("FREEZE_DAYS", "7")))
    # Таймауты
    viewing_deadline_hours: int  = field(default_factory=lambda: int(_opt("VIEWING_DEADLINE_HOURS", "24")))
    report_deadline_hours: int   = field(default_factory=lambda: int(_opt("REPORT_DEADLINE_HOURS", "2")))


@dataclass(frozen=True)
class AppConfig:
    telegram: TelegramConfig     = field(default_factory=TelegramConfig)
    sheets: SheetsConfig         = field(default_factory=SheetsConfig)
    scheduler: SchedulerConfig   = field(default_factory=SchedulerConfig)
    realtor: RealtorConfig       = field(default_factory=RealtorConfig)


_config: AppConfig | None = None


def get_config() -> AppConfig:
    global _config
    if _config is None:
        _config = AppConfig()
    return _config
